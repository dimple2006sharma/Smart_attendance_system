// Smart Attendance System - Frontend Logic

const API_URL = 'http://localhost:5000/api';
let socket;

// Global Fetch Interceptor to handle Session/DB Wipes gracefully
const originalFetch = window.fetch;
window.fetch = async (...args) => {
  const response = await originalFetch(...args);
  if (response.status === 401 && window.location.pathname.includes('dashboard.html')) {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'index.html';
  }
  return response;
};

// --- UTILS & CORE ---
const qs = (selector) => document.querySelector(selector);
const on = (selector, event, handler) => { 
  const el = qs(selector); 
  if (el) el.addEventListener(event, handler); 
};

const showToast = (message, type = 'error') => {
  const container = qs('#toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => { if(container.contains(toast)) container.removeChild(toast); }, 4500);
};

const initTheme = () => {
  const currentTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', currentTheme);
  on('#theme-toggle', 'click', () => {
    let theme = document.documentElement.getAttribute('data-theme');
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
  });
};
initTheme();

const getToken = () => localStorage.getItem('token');
const getUser = () => JSON.parse(localStorage.getItem('user') || 'null');

const requireAuth = () => { if (!getToken() && window.location.pathname.includes('dashboard.html')) window.location.href = 'index.html'; };
const redirectIfAuth = () => { if (getToken() && window.location.pathname.includes('index.html')) window.location.href = 'dashboard.html'; };

requireAuth();
redirectIfAuth();

// --- AUTH (index.html) ---
if (qs('#auth-form')) {
  let isLogin = true;

  on('#toggle-auth-link', 'click', (e) => {
    e.preventDefault();
    isLogin = !isLogin;
    qs('#auth-title').textContent = isLogin ? 'Log In' : 'Sign Up';
    qs('#auth-subtitle').textContent = isLogin ? 'Access your account' : 'Create a new account';
    qs('#submit-btn').textContent = isLogin ? 'Log In' : 'Sign Up';
    qs('#toggle-auth-link').textContent = isLogin ? 'Sign Up' : 'Log In';
    qs('#toggle-auth-text').firstChild.textContent = isLogin ? "Don't have an account? " : "Already have an account? ";
    
    if (isLogin) {
      qs('#name-group').classList.add('hidden');
      qs('#role-group').classList.add('hidden');
      qs('#name').removeAttribute('required');
    } else {
      qs('#name-group').classList.remove('hidden');
      qs('#role-group').classList.remove('hidden');
      qs('#name').setAttribute('required', 'true');
    }
  });

  // Password Toggle
  on('#toggle-pwd-icon', 'click', (e) => {
    const pwdInput = qs('#password');
    const icon = e.target;
    if (pwdInput.type === 'password') {
      pwdInput.type = 'text';
      icon.classList.replace('fa-eye-slash', 'fa-eye');
    } else {
      pwdInput.type = 'password';
      icon.classList.replace('fa-eye', 'fa-eye-slash');
    }
  });

  // Role Pill Selection
  document.querySelectorAll('.role-pill').forEach(pill => {
    pill.addEventListener('click', (e) => {
      document.querySelectorAll('.role-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      qs('#role').value = pill.getAttribute('data-role');
    });
  });

  on('#auth-form', 'submit', async (e) => {
    e.preventDefault();
    const btn = qs('#submit-btn');
    btn.disabled = true;
    btn.classList.add('loading');

    const email = qs('#email').value;
    const password = qs('#password').value;
    const name = qs('#name').value;
    const role = qs('#role').value;

    const endpoint = isLogin ? '/auth/login' : '/auth/register';
    const body = isLogin ? { email, password } : { name, email, password, role };

    try {
      const res = await fetch(`${API_URL}${endpoint}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Authentication failed');
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data));
      window.location.href = 'dashboard.html';
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  });
}

// --- SPA VIEW ROUTING ---
function switchView(viewId) {
  document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  
  const targetView = qs(`#${viewId}`);
  if(targetView) targetView.classList.add('active');
  
  const targetNav = qs(`[data-view="${viewId}"]`);
  if(targetNav) targetNav.classList.add('active');
}

// --- DASHBOARD INIT (dashboard.html) ---
if (qs('#user-greeting')) {
  const user = getUser();
  qs('#user-greeting').textContent = `Logged in as ${user.name.split(' ')[0]}`;
  
  on('#logout-btn', 'click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'index.html';
  });

  on('#sidebar-toggle', 'click', () => {
    qs('.sidebar').classList.toggle('collapsed');
  });

  // Render Sidebar specific to Role
  const sidemenu = qs('#side-menu');
  let menuHTML = '';
  if (user.role === 'admin') {
    menuHTML += `<div class="nav-item active" data-view="view-dashboard" data-tooltip="Overview"><i class="fas fa-chart-pie"></i><span>Overview</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-generate-qr" data-tooltip="Generate QR"><i class="fas fa-qrcode"></i><span>Generate QR</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-history" data-tooltip="Live Attendance"><i class="fas fa-list-alt"></i><span>Live Attendance</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-manage" data-tooltip="Manage Sessions"><i class="fas fa-folder-open"></i><span>Manage Sessions</span></div>`;
  } else {
    menuHTML += `<div class="nav-item active" data-view="view-dashboard" data-tooltip="Dashboard"><i class="fas fa-home"></i><span>Dashboard</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-mark-attendance" data-tooltip="Scan QR"><i class="fas fa-camera"></i><span>Scan QR</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-history" data-tooltip="My History"><i class="fas fa-history"></i><span>My History</span></div>`;
    menuHTML += `<div class="nav-item" data-view="view-reports" data-tooltip="Reports"><i class="fas fa-chart-bar"></i><span>Reports</span></div>`;
  }
  menuHTML += `<div class="nav-item" data-view="view-profile" data-tooltip="Profile"><i class="fas fa-user-circle"></i><span>Profile</span></div>`;
  sidemenu.innerHTML = menuHTML;

  // Add click listeners to side menu items
  document.querySelectorAll('#side-menu .nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      switchView(item.getAttribute('data-view'));
      if(window.innerWidth <= 768) qs('.sidebar').classList.add('collapsed'); // Auto-close on mobile
    });
  });

  // Profile Form Logic
  qs('#profile-name').value = user.name || '';
  qs('#profile-email').value = user.email || '';
  if (qs('#profile-phone')) qs('#profile-phone').value = user.phone || '';
  if (qs('#profile-studentId')) qs('#profile-studentId').value = user.studentId || '';
  if (qs('#profile-department')) qs('#profile-department').value = user.department || '';

  on('#profile-form', 'submit', async(e) => {
    e.preventDefault();
    const btn = qs('#profile-form .btn');
    btn.classList.add('loading');
    
    // Construct body payload dynamically
    const bodyPayload = {
      name: qs('#profile-name').value,
      password: qs('#profile-password').value || undefined
    };
    if (qs('#profile-phone')) bodyPayload.phone = qs('#profile-phone').value;
    if (qs('#profile-studentId')) bodyPayload.studentId = qs('#profile-studentId').value;
    if (qs('#profile-department')) bodyPayload.department = qs('#profile-department').value;

    try {
      const res = await fetch(`${API_URL}/auth/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
        body: JSON.stringify(bodyPayload)
      });
      const data = await res.json();
      if(!res.ok) throw new Error(data.message);
      localStorage.setItem('user', JSON.stringify(data));
      qs('#user-greeting').textContent = `Logged in as ${data.name.split(' ')[0]}`;
      showToast('Profile updated successfully!', 'success');
      qs('#profile-password').value='';
    } catch(err) {
      showToast(err.message, 'error');
    } finally {
      btn.classList.remove('loading');
    }
  });

  if (user.role === 'admin') {
    qs('#admin-metrics').classList.remove('hidden');
    qs('#history-table-container').classList.remove('hidden');
    const adminChartCard = qs('#admin-chart-card');
    if (adminChartCard) adminChartCard.classList.remove('hidden');
    initAdminDashboard();
    setTimeout(renderAdminChart, 100);
  } else {
    qs('#student-metrics').classList.remove('hidden');
    qs('#history-grid').classList.remove('hidden');
    const studentChartCard = qs('#student-chart-card');
    if (studentChartCard) studentChartCard.classList.remove('hidden');
    initStudentDashboard();
  }
}

// --- ADMIN DASHBOARD LOGIC ---
let activeSessionId = null;
let attendanceList = [];

function initAdminDashboard() {
  socket = io('http://localhost:5000');

  socket.on('attendance_marked', (data) => {
    showToast(`${data.studentName} marked attendance!`, 'success');
    attendanceList.push(data);
    renderAttendanceList();
    loadAnalytics();
  });

  loadAnalytics();
  loadAllAdminSessions();

  on('#create-session-form', 'submit', async (e) => {
    e.preventDefault();
    const btn = qs('#create-session-form .btn');
    btn.disabled = true;
    btn.classList.add('loading');

    try {
      const res = await fetch(`${API_URL}/sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
        body: JSON.stringify({ title: qs('#session-title').value, durationMinutes: qs('#session-duration').value })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      
      activeSessionId = data._id;
      socket.emit('join_session', activeSessionId);
      
      attendanceList = [];
      renderAttendanceList();
      showToast('Session created! Generate QR...', 'success');
      loadAnalytics();
      loadAllAdminSessions();

      qs('#qr-placeholder').classList.add('hidden');
      qs('#qrcode').innerHTML = '';
      
      new QRCode(qs("#qrcode"), {
        text: JSON.stringify({ qrToken: data.qrToken }),
        width: 256, height: 256, colorDark : "#000000", colorLight : "#ffffff", correctLevel : QRCode.CorrectLevel.H
      });

      qs('#qr-session-info').textContent = `${data.title} - Active`;

      // Countdown
      let expiryTime = new Date(data.expiresAt).getTime();
      const timerInterval = setInterval(() => {
        let now = new Date().getTime();
        let distance = expiryTime - now;

        if (distance < 0) {
          clearInterval(timerInterval);
          qs('#qr-timer').textContent = "EXPIRED";
          qs('#modal-qr-timer').textContent = "EXPIRED";
          qs('#qrcode').innerHTML = '';
          qs('#qr-placeholder').classList.remove('hidden');
          qs('#qr-placeholder').textContent = "Session Expired";
          qs('#end-session-btn').classList.add('hidden');
          qs('#show-qr-modal-btn').classList.add('hidden');
          qs('#qr-modal-overlay').classList.remove('active');
        } else {
          let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          let seconds = Math.floor((distance % (1000 * 60)) / 1000);
          qs('#qr-timer').textContent = `Active Time Left: ${minutes}m ${seconds}s`;
          qs('#modal-qr-timer').textContent = `Expires in: ${minutes}m ${seconds}s`;
        }
      }, 1000);

      qs('#active-session-status').style.display = 'block';
      qs('#end-session-btn').classList.remove('hidden');
      qs('#show-qr-modal-btn').classList.remove('hidden');
      qs('#qr-modal-overlay').classList.add('active');

    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  });

  on('#show-qr-modal-btn', 'click', () => { qs('#qr-modal-overlay').classList.add('active'); });
  on('#close-modal-btn', 'click', () => { qs('#qr-modal-overlay').classList.remove('active'); });

  const filterAdminHistory = () => {
    const term = qs('#history-search').value.toLowerCase();
    const dateVal = qs('#history-date-filter').value;
    
    document.querySelectorAll('#attendance-tbody tr').forEach(row => {
      if(row.querySelector('td[colspan]')) return;
      const text = row.textContent.toLowerCase();
      const rowDate = row.getAttribute('data-date') || '';
      const matchSearch = text.includes(term);
      const matchDate = dateVal ? rowDate === dateVal : true;
      
      row.style.display = (matchSearch && matchDate) ? '' : 'none';
    });
  };

  on('#history-search', 'input', filterAdminHistory);
  if(qs('#history-date-filter')) on('#history-date-filter', 'change', filterAdminHistory);

  on('#export-history-btn', 'click', () => {
    if (attendanceList.length === 0) return;
    const csvContent = "data:text/csv;charset=utf-8," + "Name,Email,Timestamp\n" + attendanceList.map(item => `${item.studentName},${item.studentEmail},${new Date(item.timestamp).toLocaleString()}`).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "attendance.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });

  on('#refresh-history-btn', 'click', renderAttendanceList);

  on('#end-session-btn', 'click', async () => {
    if(!activeSessionId) return;
    try {
      const res = await fetch(`${API_URL}/sessions/${activeSessionId}/stop`, { method: 'PUT', headers: { 'Authorization': `Bearer ${getToken()}` } });
      const data = await res.json();
      if(!res.ok) throw new Error(data.message);
      
      showToast('Session ended early', 'info');
      qs('#qr-timer').textContent = "ENDED EARLY";
      qs('#modal-qr-timer').textContent = "ENDED EARLY";
      qs('#qrcode').innerHTML = '';
      qs('#qr-placeholder').classList.remove('hidden');
      qs('#qr-placeholder').textContent = "Session Formally Closed.";
      qs('#end-session-btn').classList.add('hidden');
      qs('#show-qr-modal-btn').classList.add('hidden');
      qs('#qr-modal-overlay').classList.remove('active');
    } catch(err) {
      showToast(err.message, 'error');
    }
  });
}

function renderAttendanceList() {
  const tbody = qs('#attendance-tbody');
  qs('#live-attendance-count').textContent = `Total Scans: ${attendanceList.length}`;
  if (attendanceList.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="text-center" style="color: #666;">No valid records...</td></tr>';
    return;
  }
  tbody.innerHTML = '';
  attendanceList.forEach((att, index) => {
    let dateObj = new Date(att.timestamp);
    let yyyy_mm_dd = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2,'0')}-${String(dateObj.getDate()).padStart(2,'0')}`;
    tbody.innerHTML += `<tr data-date="${yyyy_mm_dd}"><td>${index + 1}</td><td>${att.studentName}</td><td>${att.studentEmail}</td><td>${dateObj.toLocaleTimeString()}</td></tr>`;
  });
}

async function loadAllAdminSessions() {
  const tbody = qs('#manage-sessions-tbody');
  tbody.innerHTML = '<tr><td colspan="3" class="text-center">Loading...</td></tr>';
  try {
    const res = await fetch(`${API_URL}/sessions`, { method: 'GET', headers: { 'Authorization': `Bearer ${getToken()}` } });
    const data = await res.json();
    if(!res.ok) throw new Error(data.message);
    if(data.length === 0) { tbody.innerHTML = '<tr><td colspan="3" class="text-center">No sessions created.</td></tr>'; return; }
    tbody.innerHTML = '';
    data.forEach(sess => {
      tbody.innerHTML += `
        <tr>
          <td><strong style="color: var(--primary-color);">${sess.title}</strong></td>
          <td>${new Date(sess.createdAt).toLocaleDateString()}</td>
          <td><button class="btn btn-danger" onclick="deleteSession('${sess._id}')" style="padding: 0.3rem 0.6rem; width: auto; font-size: 0.8rem;">Delete</button></td>
        </tr>`;
    });
  } catch(err) {
    tbody.innerHTML = `<tr><td colspan="3" class="text-center" style="color: var(--error-color);">Error: ${err.message}</td></tr>`;
  }
}

window.deleteSession = async (id) => {
  if(!confirm("Are you sure you want to delete this session and all its attendance records permanently?")) return;
  try {
    const res = await fetch(`${API_URL}/sessions/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${getToken()}` } });
    if(!res.ok) throw new Error('Failed to delete session');
    showToast('Session deleted', 'success');
    loadAllAdminSessions();
    loadAnalytics();
  } catch(err) {
    showToast(err.message, 'error');
  }
}

// --- STUDENT DASHBOARD LOGIC ---
let html5QrcodeScanner;

function initStudentDashboard() {
  loadStudentHistory();
  loadAnalytics();

  on('#refresh-history-btn', 'click', () => { loadStudentHistory(); loadAnalytics(); });
  
  const filterStudentHistory = () => {
    const term = qs('#history-search').value.toLowerCase();
    const dateVal = qs('#history-date-filter').value;
    
    document.querySelectorAll('.history-card').forEach(card => {
      const text = card.textContent.toLowerCase();
      const cardDate = card.getAttribute('data-date');
      const matchSearch = text.includes(term);
      const matchDate = dateVal ? cardDate === dateVal : true;
      
      card.style.display = (matchSearch && matchDate) ? 'flex' : 'none';
    });
  };

  on('#history-search', 'input', filterStudentHistory);
  if(qs('#history-date-filter')) on('#history-date-filter', 'change', filterStudentHistory);
  
  on('#export-history-btn', 'click', () => {
    if (!window.studentHistoryData || window.studentHistoryData.length === 0) return;
    const csvContent = "data:text/csv;charset=utf-8," + "Session Title,Date,Time,Status\n" + window.studentHistoryData.map(item => {
      let d = new Date(item.timestamp);
      return `"${item.session.title}","${d.toLocaleDateString()}","${d.toLocaleTimeString()}","Present"`;
    }).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "student_attendance_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });

  on('#start-scan-btn', 'click', () => {
    qs('#start-scan-btn').classList.add('hidden');
    qs('#stop-scan-btn').classList.remove('hidden');
    html5QrcodeScanner = new Html5Qrcode("reader");
    
    const qrCodeSuccessCallback = async (decodedText, decodedResult) => {
      html5QrcodeScanner.pause();
      try {
        const qrData = JSON.parse(decodedText);
        if(!qrData.qrToken) throw new Error("Invalid QR format");
        const res = await fetch(`${API_URL}/attendance/mark`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
          body: JSON.stringify({ qrToken: qrData.qrToken })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message);
        showToast('Attendance Marked Successfully!', 'success');
        loadStudentHistory();
        loadAnalytics();
      } catch (err) {
        showToast(err.message.includes('JSON') ? 'Invalid Organization QR Code' : err.message, 'error');
      } finally {
        setTimeout(stopScanner, 3000);
      }
    };
    html5QrcodeScanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } }, qrCodeSuccessCallback, (e) => {}).catch(err => {
      showToast("Camera access denied or error.", "error");
      stopScanner();
    });
  });

  on('#stop-scan-btn', 'click', stopScanner);
}

function stopScanner() {
  if (html5QrcodeScanner) {
    html5QrcodeScanner.stop().then(() => {
      html5QrcodeScanner.clear();
      qs('#start-scan-btn').classList.remove('hidden');
      qs('#stop-scan-btn').classList.add('hidden');
    }).catch(err => console.log(err));
  }
}

async function loadStudentHistory() {
  const grid = qs('#history-grid');
  grid.innerHTML = '<div class="text-center" style="color: #666; width: 100%;">Loading...</div>';
  try {
    const res = await fetch(`${API_URL}/attendance/history`, { method: 'GET', headers: { 'Authorization': `Bearer ${getToken()}` } });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    if (data.length === 0) { grid.innerHTML = '<div class="text-center" style="color: #666; width: 100%;">No valid attendance history found.</div>'; return; }
    
    // Sort array by newest first cleanly covering the "filter by date" req
    data.sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp));
    window.studentHistoryData = data;
    
    if (data.length > 0) {
      const lastDate = new Date(data[0].timestamp).toLocaleDateString();
      if(qs('#student-last-attendance')) qs('#student-last-attendance').textContent = lastDate;
    }
    
    grid.innerHTML = '';
    data.forEach(att => {
      let dateObj = new Date(att.timestamp);
      let yyyy_mm_dd = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2,'0')}-${String(dateObj.getDate()).padStart(2,'0')}`;
      grid.innerHTML += `
        <div class="history-card" data-date="${yyyy_mm_dd}">
          <div class="hc-title">${att.session.title}</div>
          <div class="hc-date">${dateObj.toLocaleDateString()} at ${dateObj.toLocaleTimeString()}</div>
          <div class="hc-status" style="color: #10B981; font-weight: 500;">✓ Present</div>
        </div>`;
    });
  } catch (err) {
    grid.innerHTML = `<div class="text-center" style="color: var(--error-color); width: 100%;">Failed to load history: ${err.message}</div>`;
  }
}

let attendanceChartInstance = null;
function renderChart(attended, total) {
  const ctx = document.getElementById('attendanceChart');
  if(!ctx) return;
  if(attendanceChartInstance) attendanceChartInstance.destroy();
  const missed = Math.max(0, total - attended);
  
  attendanceChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Attended', 'Missed'],
      datasets: [{
        data: [attended, missed],
        backgroundColor: ['#3B82F6', '#93C5FD'],
        borderWidth: 0, hoverOffset: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '70%',
      animation: { duration: 1000, easing: 'easeOutQuart' },
      plugins: { 
        legend: { display: false }, 
        tooltip: { 
          backgroundColor: '#FFFFFF', titleColor: '#6B7280', bodyColor: '#3B82F6', borderColor: '#E5E7EB', borderWidth: 1, padding: 10,
          callbacks: { label: function(context) { return ` ${context.label}: ${context.raw}`; } } 
        } 
      }
    }
  });
}

function renderAdminChart() {
  const ctx = document.getElementById('adminWeeklyChart');
  if(!ctx) return;
  
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Attendance',
        data: [45, 52, 38, 60, 48, 20, 0],
        backgroundColor: '#3B82F6',
        hoverBackgroundColor: '#93C5FD',
        borderRadius: 8,
        borderWidth: 0,
        barThickness: window.innerWidth > 768 ? 40 : 20
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 1000, easing: 'easeOutQuart' },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#FFFFFF',
          titleColor: '#6B7280',
          bodyColor: '#3B82F6',
          borderColor: '#E5E7EB',
          borderWidth: 1,
          padding: 10,
          displayColors: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: '#E5E7EB', drawBorder: false },
          ticks: { color: '#6B7280', padding: 10 }
        },
        x: {
          grid: { display: false, drawBorder: false },
          ticks: { color: '#6B7280', padding: 10 }
        }
      }
    }
  });
}

let studentDashboardChartInstance = null;
function renderStudentDashboardChart(attended, total) {
  const ctx = document.getElementById('studentPercentageChart');
  if(!ctx) return;
  if(studentDashboardChartInstance) studentDashboardChartInstance.destroy();
  const missed = Math.max(0, total - attended);
  
  studentDashboardChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Present', 'Absent'],
      datasets: [{
        data: [attended, missed],
        backgroundColor: ['#3B82F6', '#93C5FD'],
        hoverBackgroundColor: ['#2563EB', '#60A5FA'],
        borderWidth: 0, hoverOffset: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '70%',
      animation: { duration: 1000, easing: 'easeOutQuart' },
      plugins: { 
        legend: { position: 'bottom', labels: { color: '#6B7280', padding: 20, usePointStyle: true, pointStyle: 'circle' } }, 
        tooltip: { 
          backgroundColor: '#FFFFFF', titleColor: '#6B7280', bodyColor: '#3B82F6', borderColor: '#E5E7EB', borderWidth: 1, padding: 10,
          callbacks: { label: function(context) { return ` ${context.label}: ${context.raw}`; } } 
        } 
      }
    }
  });
}

async function loadAnalytics() {
  try {
    const res = await fetch(`${API_URL}/attendance/analytics`, { method: 'GET', headers: { 'Authorization': `Bearer ${getToken()}` } });
    const data = await res.json();
    if(!res.ok) throw new Error(data.message);

    if(data.role === 'admin') {
      const qsId = id => { const el = qs(id); if (el) el.textContent = data[id.replace('admin-','')]; };
      if(qs('#admin-total-sessions')) qs('#admin-total-sessions').textContent = data.totalSessions;
      if(qs('#admin-total-attendances')) qs('#admin-total-attendances').textContent = data.totalAttendances;
      if(qs('#admin-avg-attendance')) qs('#admin-avg-attendance').textContent = data.avgAttendance;
    } else {
      if(qs('#student-total-attended')) qs('#student-total-attended').textContent = data.myAttendances;
      if(qs('#student-attendance-rate')) qs('#student-attendance-rate').textContent = `${data.attendancePercentage}%`;
      renderChart(data.myAttendances, data.totalSessions);
      renderStudentDashboardChart(data.myAttendances, data.totalSessions);
      
      if (data.attendancePercentage < 75 && !window.lowAttendanceNotified && data.totalSessions > 0) {
        showToast(`Warning: Your attendance rate is ${data.attendancePercentage}% (< 75%)`, 'error');
        window.lowAttendanceNotified = true;
      }
    }
  } catch (err) {
    console.error("Failed to load analytics: ", err.message);
  }
}

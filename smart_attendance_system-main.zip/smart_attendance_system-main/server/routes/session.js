const express = require('express');
const router = express.Router();
const { createSession, getSession, getSessions, stopSession, deleteSession } = require('../controllers/sessionController');
const { protect, admin } = require('../middleware/auth');

router.route('/').post(protect, admin, createSession).get(protect, admin, getSessions);
router.route('/:id').get(protect, getSession).delete(protect, admin, deleteSession);
router.route('/:id/stop').put(protect, admin, stopSession);

module.exports = router;

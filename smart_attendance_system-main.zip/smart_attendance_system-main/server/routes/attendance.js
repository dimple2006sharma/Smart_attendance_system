const express = require('express');
const router = express.Router();
const { markAttendance, getSessionAttendance, getStudentHistory, getAnalytics } = require('../controllers/attendanceController');
const { protect, admin } = require('../middleware/auth');

router.post('/mark', protect, markAttendance);
router.get('/analytics', protect, getAnalytics);
router.get('/session/:id', protect, admin, getSessionAttendance);
router.get('/history', protect, getStudentHistory);

module.exports = router;

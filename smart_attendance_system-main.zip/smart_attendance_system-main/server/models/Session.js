const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  title: { type: String, required: true },
  creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  qrToken: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

// Optional: Index to automatically expire documents but since we want to keep them for records,
// we just check expiresAt manually during attendance marking.

module.exports = mongoose.model('Session', sessionSchema);

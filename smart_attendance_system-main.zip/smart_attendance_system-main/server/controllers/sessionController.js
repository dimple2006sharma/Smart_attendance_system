const Session = require('../models/Session');
const crypto = require('crypto');

// @desc    Create a new session (Class/Lecture)
// @route   POST /api/sessions
// @access  Private/Admin
exports.createSession = async (req, res) => {
  const { title, durationMinutes } = req.body; // duration in minutes

  try {
    const duration = durationMinutes || 5; // default 5 mins
    const expiresAt = new Date(Date.now() + duration * 60000);
    
    // Generate a unique token for the QR code
    const qrToken = crypto.randomBytes(32).toString('hex');

    const session = await Session.create({
      title,
      creator: req.user._id,
      qrToken,
      expiresAt,
    });

    res.status(201).json(session);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get session details by ID or token (to verify token validity early if needed)
// @route   GET /api/sessions/:id
// @access  Private
exports.getSession = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id);
    if (!session) return res.status(404).json({ message: 'Session not found' });
    res.json(session);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all sessions for the admin
// @route   GET /api/sessions
// @access  Private/Admin
exports.getSessions = async (req, res) => {
  try {
    const sessions = await Session.find({ creator: req.user._id }).sort('-createdAt');
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Manually terminate an active session early
// @route   PUT /api/sessions/:id/stop
// @access  Private/Admin
exports.stopSession = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id);
    if (!session) return res.status(404).json({ message: 'Session not found' });
    
    // Set expiration to current time
    session.expiresAt = new Date();
    await session.save();
    
    res.json({ message: 'Session ended successfully', session });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete a session and its attendance records
// @route   DELETE /api/sessions/:id
// @access  Private/Admin
exports.deleteSession = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id);
    if (!session) return res.status(404).json({ message: 'Session not found' });
    
    // Ensure the user actually created this session
    if (session.creator.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this session' });
    }

    // Delete attendance records related to the session
    const Attendance = require('../models/Attendance');
    await Attendance.deleteMany({ session: session._id });

    await session.deleteOne();
    res.json({ message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

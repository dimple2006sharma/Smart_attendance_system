const Attendance = require('../models/Attendance');
const Session = require('../models/Session');
const User = require('../models/User');

// @desc    Mark attendance by scanning QR
// @route   POST /api/attendance/mark
// @access  Private/Student
exports.markAttendance = async (req, res) => {
  const { qrToken } = req.body;
  const studentId = req.user._id;

  try {
    // Find the session with this token
    const session = await Session.findOne({ qrToken });

    if (!session) {
      return res.status(404).json({ message: 'Invalid QR Code.' });
    }

    // Check if session has expired
    if (new Date() > new Date(session.expiresAt)) {
      return res.status(400).json({ message: 'QR Code has expired.' });
    }

    // Check if student already marked attendance
    const alreadyMarked = await Attendance.findOne({ session: session._id, student: studentId });

    if (alreadyMarked) {
      return res.status(400).json({ message: 'Already marked' });
    }

    const attendance = await Attendance.create({
      session: session._id,
      student: studentId
    });

    // Notify the admin via Socket.io
    // Admin is assumed to be subscribed to the 'join_session' room with session ID
    if (req.io) {
      req.io.to(session._id.toString()).emit('attendance_marked', {
        studentName: req.user.name,
        studentEmail: req.user.email,
        timestamp: attendance.timestamp
      });
    }

    res.status(201).json({ message: 'Attendance marked successfully', attendance });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Attendance already marked.' });
    }
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get attendance for a specific session
// @route   GET /api/attendance/session/:id
// @access  Private/Admin
exports.getSessionAttendance = async (req, res) => {
  try {
    const records = await Attendance.find({ session: req.params.id })
                                    .populate('student', 'name email');
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get student's own attendance history
// @route   GET /api/attendance/history
// @access  Private/Student
exports.getStudentHistory = async (req, res) => {
  try {
    const history = await Attendance.find({ student: req.user._id })
                                    .populate('session', 'title createdAt expiresAt');
    res.json(history);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get analytics for dashboard
// @route   GET /api/attendance/analytics
// @access  Private
exports.getAnalytics = async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      const totalSessions = await Session.countDocuments({ creator: req.user._id });
      // Number of unique students who attended at least one of their sessions
      const adminSessions = await Session.find({ creator: req.user._id }).select('_id');
      const sessionIds = adminSessions.map(s => s._id);
      
      const totalAttendances = await Attendance.countDocuments({ session: { $in: sessionIds } });
      const uniqueStudents = await Attendance.distinct('student', { session: { $in: sessionIds } });
      
      res.json({
        role: 'admin',
        totalSessions,
        totalAttendances,
        totalStudents: uniqueStudents.length,
        avgAttendance: totalSessions > 0 ? (totalAttendances / totalSessions).toFixed(1) : 0
      });
    } else {
      const myAttendances = await Attendance.countDocuments({ student: req.user._id });
      // Total available active or past sessions (simplified)
      const allSessions = await Session.countDocuments();
      
      res.json({
        role: 'student',
        myAttendances,
        totalSessions: allSessions,
        attendancePercentage: allSessions > 0 ? Math.round((myAttendances / allSessions) * 100) : 0
      });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
